# Staff Role Panels Bot

Run npm install, npm run deploy, npm start
